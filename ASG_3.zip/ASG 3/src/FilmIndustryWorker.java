import java.util.List;

public abstract class FilmIndustryWorker {
    private String firstName;
    private String lastName;
    private int yearsActive;
    private List<String> awardsWon;


    public FilmIndustryWorker(String firstName, String lastName, int yearsActive, List<String> awardsWon) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.yearsActive = yearsActive;
        this.awardsWon = awardsWon;
    }

    public abstract boolean specializesInGenre(MovieGenre genre);

    public int getYearsActive() {
        return yearsActive;

    }
    @Override
    public String toString() {
        return "Name: " + firstName + " " + lastName +
                ", Years Active: " + yearsActive +
                ", Awards Won: " + awardsWon;
    }
}
