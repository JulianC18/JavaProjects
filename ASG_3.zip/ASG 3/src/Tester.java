import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class Tester {
    public static void main(String[] args) {
        List<Movie> myMovies = new ArrayList<>();


        Director director1 = new Director("Steven", "Spielberg", 20, List.of("Oscar"), true);
        Producer producer1 = new Producer("Jerry", "Bruckheimer", 10, List.of("Emmy"));

        Movie movie1 = new Movie("Jurassic Park", director1, producer1, 1993, MPAARating.PG_13, MovieGenre.ACTION);
        movie1.addActor(new Actor("Sam", "Neill", Actor.ActingStyle.METHOD, 15, List.of("Golden Globe")));
        movie1.addActor(new Actor("Laura", "Dern", Actor.ActingStyle.CHARACTER, 12, List.of("BAFTA")));

        Director director2 = new Director("Christopher", "Nolan", 15, List.of("Oscar"), true);
        Producer producer2 = new Producer("Emma", "Thomas", 12, List.of("BAFTA"));

        Movie movie2 = new Movie("Inception", director2, producer2, 2010, MPAARating.PG_13, MovieGenre.SCIFI);
        movie2.addActor(new Actor("Leonardo", "DiCaprio", Actor.ActingStyle.METHOD, 20, List.of("Oscar")));
        movie2.addActor(new Actor("Ellen", "Page", Actor.ActingStyle.IMPROV, 10, List.of("Emmy")));


        Director director3 = new Director("Simon", "Smith", 10, List.of("BAFTA"), true);
        Producer producer3 = new Producer("Jerry", "Seinfeld", 8, List.of("Golden Globe"));
        Movie movie3 = new Movie("Bee Movie", director3, producer3, 2007, MPAARating.PG, MovieGenre.COMEDY);
        movie3.addActor(new Actor("Jerry", "Seinfeld", Actor.ActingStyle.IMPROV, 8, List.of("Golden Globe")));
        movie3.addActor(new Actor("Renée", "Zellweger", Actor.ActingStyle.CHARACTER, 15, List.of("Oscar")));

        Director director4 = new Director("John", "Lasseter", 20, List.of("Oscar"), true);
        Producer producer4 = new Producer("Darla", "K. Anderson", 18, List.of("Emmy"));
        Movie movie4 = new Movie("Cars", director4, producer4, 2006, MPAARating.G, MovieGenre.SCIFI);
        movie4.addActor(new Actor("Owen", "Wilson", Actor.ActingStyle.IMPROV, 20, List.of("Golden Globe")));
        movie4.addActor(new Actor("Paul", "Newman", Actor.ActingStyle.CHARACTER, 50, List.of("Oscar")));


        myMovies.add(movie1);
        myMovies.add(movie3);
        myMovies.add(movie4);
        boolean add = myMovies.add(movie2);

        // Iterate over the list, printing each movie
        System.out.println("Before Sorting:");
        for (Movie movie : myMovies) {
            System.out.println(movie);
        }

        // Sort the list of movies
        Collections.sort(myMovies);


        // Iterate over the sorted list again to confirm sorting
        System.out.println("\nAfter Sorting:");
        for (Movie movie : myMovies) {
            System.out.println(movie);

        }
    }
}
