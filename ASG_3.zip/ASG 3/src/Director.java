import java.util.List;

public class Director extends FilmIndustryWorker {
    private boolean usesDigitalTechnologies;

    public Director(String firstName, String lastName, int yearsActive, List<String> awardsWon, boolean usesDigitalTechnologies) {
        super(firstName, lastName, yearsActive, awardsWon);
        this.usesDigitalTechnologies = usesDigitalTechnologies;
    }

    @Override
    public boolean specializesInGenre(MovieGenre genre) {
        if (usesDigitalTechnologies && genre == MovieGenre.SCIFI) {
            return true;
        }
        return genre != MovieGenre.SCIFI && (genre == MovieGenre.ROMANCE || genre == MovieGenre.COMEDY ||
                genre == MovieGenre.HORROR || genre == MovieGenre.ACTION || genre == MovieGenre.DRAMA);
    }

    @Override
    public String toString() {
        return super.toString() + ", Uses Digital Technologies: " + usesDigitalTechnologies;
    }
}
