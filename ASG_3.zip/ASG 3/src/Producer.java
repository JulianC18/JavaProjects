import java.util.List;

public class Producer extends FilmIndustryWorker {

    public Producer(String firstName, String lastName, int yearsActive, List<String> awardsWon) {
        super(firstName, lastName, yearsActive, awardsWon);
    }

    @Override
    public boolean specializesInGenre(MovieGenre genre) {
        return getYearsActive() > 5 || genre != MovieGenre.SCIFI;
    }
}
