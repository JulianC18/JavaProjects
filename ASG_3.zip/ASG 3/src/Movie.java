import java.util.ArrayList;
import java.util.List;

public class Movie implements Comparable<Movie> {
    private String title;
    private Director director;
    private Producer producer;
    private int year;
    private MPAARating rating;
    private List<Actor> actors;
    private MovieGenre genre;

    public Movie(String title, Director director, Producer producer, int year, MPAARating rating, MovieGenre genre) {
        this.title = title;
        this.director = director;
        this.producer = producer;
        this.year = year;
        this.rating = rating;
        this.genre = genre;
        this.actors = new ArrayList<>();
        if (!director.specializesInGenre(genre)) {
            throw new IllegalArgumentException("Director does not specialize in provided genre.");
        }
        if (!producer.specializesInGenre(genre)) {
            throw new IllegalArgumentException("Producer does not specialize in provided genre.");
        }
    }

    public void addActor(Actor actor) {
        if (!actor.specializesInGenre(genre)) {
            throw new IllegalArgumentException("Actor does not specialize in the movie's genre.");
        }
        actors.add(actor);
    }

    @Override
    public int compareTo(Movie o) {
        return Integer.compare(this.year, o.year);
    }

    @Override
    public String toString() {
        return "(" + year + ") " + title + " - " + genre + " - rated: " + rating;
    }
}
