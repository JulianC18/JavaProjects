import java.util.List;

public class Actor extends FilmIndustryWorker {
    private ActingStyle actingStyle;

    public enum ActingStyle {
        METHOD, CHARACTER, IMPROV
    }

    public Actor(String firstName, String lastName, ActingStyle actingStyle, int yearsActive, List<String> awardsWon) {
        super(firstName, lastName, yearsActive, awardsWon);
        this.actingStyle = actingStyle;
    }

    @Override
    public boolean specializesInGenre(MovieGenre genre) {
        if (genre == MovieGenre.ACTION || genre == MovieGenre.ROMANCE) {
            return true;
        } else if ((genre == MovieGenre.HORROR || genre == MovieGenre.SCIFI) && getYearsActive() >= 10) { // Change > to >=
            return true;
        } else {
            return (genre == MovieGenre.COMEDY || genre == MovieGenre.DRAMA) && (actingStyle == ActingStyle.IMPROV || actingStyle == ActingStyle.CHARACTER);
        }
    }


    @Override
    public String toString() {
        return super.toString() + ", Acting Style: " + actingStyle;
    }
}
