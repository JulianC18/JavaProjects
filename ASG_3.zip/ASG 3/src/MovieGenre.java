public enum MovieGenre {
    HORROR, SCIFI , ACTION, DRAMA, ROMANCE, COMEDY
}
