import java.util.ArrayList;
//I Wasn't sure how to implement javadocs as i wasn't in class last week due to a doctors appointment
enum mpaarating {
    G, PG, PG13, R
}

class Actor {
    private int age;
    private String firstName;
    private String lastName;

    public Actor(int age, String firstName, String lastName) {
        if (age < 0) {
            throw new IllegalArgumentException("Invalid age provided");
        }
        this.age = age;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void updateAge() {
        age++;
    }

    @Override
    public String toString() {
        return "actor : " + firstName + ", " + lastName + " (" + age + ")";
    }
}

class Song {
    private String title;
    private String bandname;
    private double length;
    private String genre;

    public Song(String title, String bandname, double length, String genre) {
        this.title = title;
        this.bandname = bandname;
        this.length = length;
        this.genre = genre;
    }

    public String getTitle() {
        return title;
    }

    public String getBandname() {
        return bandname;
    }

    public double getLength() {
        return length;
    }

    public String getGenre() {
        return genre;
    }

    public void setBandname(String newBandName) {
        this.bandname = newBandName;
    }

    @Override
    public String toString() {
        return "song : " + title + " by " + bandname + " (" + genre + ")";
    }
}

class Movie {
    private String name;
    private double movielength;
    private int releaseyear;
    private mpaarating rating;
    private ArrayList<Actor> actors;
    private ArrayList<Song> songs;

    public Movie(String name, ArrayList<Actor> actors, ArrayList<Song> songs, int releaseyear, mpaarating rating, double movielength) {
        if (releaseyear < 0 || movielength < 0) {
            throw new IllegalArgumentException("Invalid release year or movie length");
        }
        this.name = name;
        this.actors = actors;
        this.songs = songs;
        this.releaseyear = releaseyear;
        this.rating = rating;
        this.movielength = movielength;
    }

    public void addActor(Actor actor) {
        actors.add(actor);
    }

    public void addSong(Song song) {
        songs.add(song);
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("movie : " + name + " (" + releaseyear + " - ");

        if (!actors.isEmpty()) {
            result.append(actors.get(0).getLastName());
        }

        result.append(" - ").append(rating).append(")\n------------------------------");

        return result.toString();
    }
}

