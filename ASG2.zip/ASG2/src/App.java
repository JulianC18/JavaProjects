import java.util.ArrayList;


public class App {

    public static void main(String[] args) {
        ArrayList<Actor> actors1 = new ArrayList<>();
        actors1.add(new Actor(30, "Sheridan", "Cruz"));

        ArrayList<Song> songs1 = new ArrayList<>();
        songs1.add(new Song("Some Song", "Some Band", 3.5, "Rock"));

        Movie movie1 = new Movie("Ready Player One", actors1, songs1, 2018, mpaarating.R, 2.5);

        ArrayList<Actor> actors2 = new ArrayList<>();
        actors2.add(new Actor(25, "Tom", "Hanks"));

        ArrayList<Song> songs2 = new ArrayList<>();
        songs2.add(new Song("Another Song", "Another Band", 4.2, "Pop"));

        Movie movie2 = new Movie("Ferrari", actors2, songs2, 2023, mpaarating.R, 2.8);

        ArrayList<Movie> movies = new ArrayList<>();
        movies.add(movie1);
        movies.add(movie2);

        for (Movie movie : movies) {
            System.out.println(movie.toString());
        }
    }
}
