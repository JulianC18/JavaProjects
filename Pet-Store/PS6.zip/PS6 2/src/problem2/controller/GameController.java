package problem2.controller;

import problem2.model.ComboLock;
import problem2.view.GameView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameController {
    private ComboLock lock;
    private GameView view;

    public GameController(ComboLock lock, GameView view) {
        this.lock = lock;
        this.view = view;
    }

    public void setView(GameView view) {
        this.view = view;
    }

    public ActionListener getButtonAListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lock.getKey1().toggle();
                checkStatus();
            }
        };
    }

    public ActionListener getButtonBListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lock.getKey2().toggle();
                checkStatus();
            }
        };
    }

    public ActionListener getButtonCListener() {
        return new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lock.getKey3().toggle();
                checkStatus();
            }
        };
    }

    private void checkStatus() {
        if (lock.unlocks()) {
            view.updateStatus("Unlocked!");
        } else {
            view.updateStatus("Locked...");
        }
    }
}
