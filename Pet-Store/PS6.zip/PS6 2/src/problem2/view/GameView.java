package problem2.view;

import problem2.controller.GameController;
import problem2.model.ComboLock;

import javax.swing.*;
import java.awt.*;

public class GameView {
    private JFrame frame;
    private JButton buttonA;
    private JButton buttonB;
    private JButton buttonC;
    private JLabel statusLabel;

    public GameView(ComboLock lock, GameController controller) {
        frame = new JFrame("Button Puzzle Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 3));

        buttonA = new JButton("A");
        buttonB = new JButton("B");
        buttonC = new JButton("C");

        buttonA.addActionListener(controller.getButtonAListener());
        buttonB.addActionListener(controller.getButtonBListener());
        buttonC.addActionListener(controller.getButtonCListener());

        statusLabel = new JLabel("Game Status: ", JLabel.CENTER);

        panel.add(buttonA);
        panel.add(buttonB);
        panel.add(buttonC);
        frame.add(panel, BorderLayout.CENTER);
        frame.add(statusLabel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    public void updateStatus(String status) {
        statusLabel.setText(status);
    }
}
