package problem2.model;

public class ComboLock {
    private Key key1;
    private Key key2;
    private Key key3;

    public ComboLock(Key key1, Key key2, Key key3) {
        this.key1 = key1;
        this.key2 = key2;
        this.key3 = key3;
    }

    public Key getKey1() {
        return key1;
    }

    public Key getKey2() {
        return key2;
    }

    public Key getKey3() {
        return key3;
    }

    public boolean unlocks() {
        return key1.isPressed() == key1.shouldBePressed() &&
                key2.isPressed() == key2.shouldBePressed() &&
                key3.isPressed() == key3.shouldBePressed();
    }

    public void resetKeys() {
        key1.reset();
        key2.reset();
        key3.reset();
    }
}