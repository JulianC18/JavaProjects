package problem2.model;

public class Key {
    private boolean shouldBePressed;
    private boolean isPressed;

    public Key(boolean shouldBePressed) {
        this.shouldBePressed = shouldBePressed;
        this.isPressed = false; // Default state
    }

    public void toggle() {
        isPressed = !isPressed;
    }

    public void reset() {
        isPressed = false;
    }

    public boolean shouldBePressed() {
        return shouldBePressed;
    }

    public boolean isPressed() {
        return isPressed;
    }
}