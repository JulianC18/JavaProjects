package problem2;

import problem2.model.ComboLock;
import problem2.model.Key;
import problem2.view.GameView;
import problem2.controller.GameController;

public class PuzzlerApp {
    public static void main(String[] args) {
        // Initialize the keys
        Key key1 = new Key(true);
        Key key2 = new Key(false);
        Key key3 = new Key(true);

        // Initialize the lock
        ComboLock lock = new ComboLock(key1, key2, key3);

        // Initialize the controller and pass the lock
        GameController controller = new GameController(lock, null);

        // Initialize the view and connect it with the controller
        GameView view = new GameView(lock, controller);

        // Rebind the view to the controller now that both exist
        controller.setView(view);
    }
}
