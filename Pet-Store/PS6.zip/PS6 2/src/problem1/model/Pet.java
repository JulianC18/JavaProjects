package problem1.model;

public interface Pet extends Comparable<Pet> {

    String name();
    int age();

}
