package problem1.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PetRepo {
    private List<Pet> pets;

    public PetRepo() {
        this.pets = new ArrayList<>();
    }

    public void sort() {
        Collections.sort(pets);
    }

    public void add(Pet pet) {
        pets.add(pet);
    }

    public void clear() {
        pets.clear();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (Pet pet : pets) {
            builder.append(pet).append("\n");
        }
        return builder.toString();
    }
}
