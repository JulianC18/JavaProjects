package problem1.model;

public class Dog implements Pet {
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public int age() {
        return age;
    }

    @Override
    public int compareTo(Pet other) {
        return Integer.compare(this.age(), other.age());
    }


    @Override
    public String toString() {
        return "Dog: " + name + ", Age: " + age;
    }
}
