package problem1.view;

import javax.swing.*;

public class PetShopForm extends JFrame {
    private JTextField nameTextField;
    private JTextField ageTextField;
    private JComboBox<String> petTypeComboBox;
    private JButton addButton;
    private JButton clearButton;
    private JTextArea outputTextArea;
    private JButton sortButton;

    public PetShopForm() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Old Tyme Pet Shoppe");
        setSize(400, 300);
        setVisible(true);
    }

    public JTextField getNameTextField() {
        return nameTextField;
    }

    public JTextField getAgeTextField() {
        return ageTextField;
    }

    public JComboBox<String> getPetTypeComboBox() {
        return petTypeComboBox;
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JTextArea getOutputTextArea() {
        return outputTextArea;
    }

    public JButton getSortButton() {
        return sortButton;
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
