package problem1;

import problem1.model.PetRepo;
import problem1.view.PetShopForm;
import problem1.controller.PetShopController;

public class app {
    public static void main(String[] args) {
        PetRepo petRepo = new PetRepo();
        PetShopForm view = new PetShopForm();
        new PetShopController(petRepo, view);
    }
}
