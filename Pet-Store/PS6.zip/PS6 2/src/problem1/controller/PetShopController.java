package problem1.controller;

import problem1.model.*;
import problem1.view.PetShopForm;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PetShopController {
    private PetRepo petRepo;
    private PetShopForm view;

    public PetShopController(PetRepo petRepo, PetShopForm view) {
        this.petRepo = petRepo;
        this.view = view;

        // Add listeners
        view.getAddButton().addActionListener(new AddPetListener());
        view.getClearButton().addActionListener(new ClearPetsListener());
        view.getSortButton().addActionListener(new SortPetsListener());
    }

    private class AddPetListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = view.getNameTextField().getText();
            String ageText = view.getAgeTextField().getText();
            String type = (String) view.getPetTypeComboBox().getSelectedItem();

            try {
                int age = Integer.parseInt(ageText);
                if (age < 0) {
                    throw new NumberFormatException();
                }

                Pet pet;
                if ("Dog".equals(type)) {
                    pet = new Dog(name, age);
                } else {
                    pet = new Lizard(name, age);
                }

                petRepo.add(pet);
                view.getOutputTextArea().setText(petRepo.toString());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(view, "Invalid integer (must be a positive number)");
            }
        }
    }

    private class ClearPetsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            petRepo.clear();
            view.getOutputTextArea().setText("");
        }
    }

    private class SortPetsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            petRepo.sort();
            view.getOutputTextArea().setText(petRepo.toString());
        }
    }
}
