/* A Basic enumuration for valid movie genre*/
public enum MovieGenre {
    Horror,
    Scifi,
    Romamce,
    Comedy,
    Drama,
    Action,
}
