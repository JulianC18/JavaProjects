public enum actingStyle {
    Method,Charater,Improv
}
