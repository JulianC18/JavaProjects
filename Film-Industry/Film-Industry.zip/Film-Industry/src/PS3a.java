import java.util.ArrayList;

public class PS3a {

    //base-class/Abstract Class
    public abstract class FilmIndustryWorker {
        public abstract boolean specializesInGenre(MovieGenre g);
    }

    //Sub-classes For film industry worker
    public class Director extends FilmIndustryWorker {
        //fields
        private String Firstname, Lastname;
        private int numOfYearsActive;
        private boolean shootsOnDigital;

        @Override
        public boolean specializesInGenre(MovieGenre g) {
            if (g == MovieGenre.Horror || g == MovieGenre.Romamce || g == MovieGenre.Comedy || g == MovieGenre.Action
                    || g == MovieGenre.Drama) {
                return true;
            }
            if (g == MovieGenre.Scifi && shootsOnDigital) {
                return true;
            }
            return false;
        }
    }

    public class Producer extends FilmIndustryWorker {
        private String firstname, lastname;
        private int numOfYearsActive;
        private actingStyle style;

        @Override
        public boolean specializesInGenre(MovieGenre g) {
            return switch (g) {
                case Horror, Action, Comedy, Romamce, Drama -> true;
                case Scifi -> {
                    Boolean result = numOfYearsActive > 5;
                    yield result;
                }
            };
        }

    }

    public class Actor extends FilmIndustryWorker {
        private String firstname, lastname;
        private int numOfYearsActive;
        private actingStyle style;

        @Override
        public boolean specializesInGenre(MovieGenre g) {
            return switch (g) {
                case MovieGenre.Horror, MovieGenre.Action, MovieGenre.Comedy, MovieGenre.Romamce, MovieGenre.Drama ->
                        true;
                case MovieGenre.Scifi ->
                        numOfYearsActive > 3; // assuming actors need at least 3 years of experience for Scifi
                default -> false;
            };
        }
    }
    class Movie {
        ArrayList<Actor> actors = new ArrayList<>();

        //fields
        private String title;
        private int year;
        private MovieGenre genre;
        private Director director;
        private Producer producer;

        //constructor
        public Movie(String title, int year, MovieGenre genre) {
            this.title = title;
            this.year = year;
            this.genre = genre;
            this.director = new Director();
            this.producer = new Producer();
        }

        //methods
        public void addActor(Actor newActor) {
            actors.add(newActor);

        }

    }
}
