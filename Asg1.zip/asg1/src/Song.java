import java.util.ArrayList;
import java.util.Scanner;

public class Song {
    public static void main(String[] args) {
        // Prompt for the name of the song
        String songName = promptsongname();

        // Prompt for the release year
        int releaseYear = promptreleaseyear();

        ArrayList<String> writers = promptsongwriters();


        String songInfo = combinesonginfo(songName, releaseYear, writers);

        // Display the combined information
        System.out.println(songInfo);
    }

    // Part 1: Adding song information input methods

    // Method to prompt for the name of the song
    public static String promptsongname() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name of the song: ");
        return scanner.nextLine();
    }

    // Method to prompt for the release year and validate it
    public static int promptreleaseyear() {
        Scanner scanner = new Scanner(System.in);
        int releaseYear;

        while (true) {
            System.out.print("Enter the release year: ");
            if (scanner.hasNextInt()) {
                releaseYear = scanner.nextInt();
                if (releaseYear >= 0) {
                    break;
                } else {
                    System.out.println("Invalid year. Please enter a non-negative year.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next();
            }
        }

        return releaseYear;
    }

    // Method to prompt for the writers of the song
    public static ArrayList<String> promptsongwriters() {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> writers = new ArrayList<>();

        while (true) {
            System.out.print("Enter a writer's name (or type 'done' to finish): ");
            String writer = scanner.nextLine();

            if (writer.equalsIgnoreCase("done")) {
                break;
            } else {
                writers.add(writer);
            }
        }

        return writers;
    }



    // Method to combine all information into a well-formatted string
    public static String combinesonginfo(String name, int year, ArrayList<String> writers) {
        StringBuilder info = new StringBuilder();
        info.append("Song Information:\n");
        info.append("Name: ").append(name).append("\n");
        info.append("Writers: ").append(String.join(", ", writers)).append("\n");
        info.append("Release Year: ").append(year).append("\n");

        return info.toString();
    }
}
