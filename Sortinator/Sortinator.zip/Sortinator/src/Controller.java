import model.ISortinator;
import view.SortinatorView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private ISortinator model;
    private SortinatorView view;

    public Controller(ISortinator m, SortinatorView v) {
        this.model = m;
        this.view = v;

        // Event handling logic
        view.form.addButton.addActionListener(new AddButtonListener());
        view.form.crankButton.addActionListener(new CrankButtonListener());
        view.form.rmvSmallestButton.addActionListener(new RemoveSmallestButtonListener());
    }

    // Inner class for add button action listener
    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // 1. Get user input
            String itemToAddText = view.form.addItemTextField.getText();

            // 2. Validate input
            if (!isValidNumber(itemToAddText)) {
                JOptionPane.showMessageDialog(view, "Please enter a valid number");
                return;
            }

            try {
                // 3. Convert to int and update model
                int itemAsInt = Integer.parseInt(itemToAddText);
                model.add(itemAsInt);

                // 4. Update view
                view.form.textField1.setText(model.toString());
                view.form.addItemTextField.setText(""); // Clear input field
            } catch (IllegalStateException ex) {
                JOptionPane.showMessageDialog(view, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Inner class for crank button action listener
    private class CrankButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            model.crank();
            JOptionPane.showMessageDialog(view, "Machine state switched");
        }
    }

    // Inner class for remove smallest button action listener
    private class RemoveSmallestButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                int smallest = model.removeSmallest();
                JOptionPane.showMessageDialog(view, "Removed smallest: " + smallest);
                // Update view to show current state
                view.form.textField1.setText(model.toString());
            } catch (IllegalStateException ex) {
                JOptionPane.showMessageDialog(view, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Method to check if a string is a valid number
    private boolean isValidNumber(String number) {
        try {
            Integer.parseInt(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
