package view;

import javax.swing.*;
import java.awt.*;

public class SortinatorView extends JFrame {
    // formbuilder form goes here
    public SortinatorForm form = new SortinatorForm();

    // Constructor
    public SortinatorView() {
        super("Sortinator");

        // Set up the view
        setContentPane(form.myPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(500, 400));
    }
}
