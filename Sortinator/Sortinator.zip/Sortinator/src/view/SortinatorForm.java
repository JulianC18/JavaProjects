package view;

import javax.swing.*;

public class SortinatorForm {
    public JPanel myPanel;
    public JButton addButton;
    public JButton crankButton;
    public JButton rmvSmallestButton;
    public JTextField addItemTextField;
    public  JTextField textField1;

}
