package model;

import java.util.ArrayList;

public class EagerImpl implements ISortinator {

    //fields
    private boolean isAccepting; //is machine still accepting input
    private ArrayList<Integer> contents; //contents of machine

    //Consctuctor
    public EagerImpl(){
        this.contents = new ArrayList<>();
    }

    //contents = [4,2,0,-1)
    //toAdd= 1

    @Override
    public void add(int toAdd) {
        //Sanity Check
        if (!isAccepting){
            throw new IllegalStateException("Machine is not accepting entries");
    }
    //if list is empty, add contents  
        if (contents.isEmpty()){
            contents.add(toAdd);
            return;
        }
    //
        for (int i = 0; i < contents.size(); i++){
            //now have to find where toAdd goes
            if (contents.get(i)< toAdd){
                contents.add(i, toAdd);
            }
        }
    }

    @Override
    public void crank() {
        if(isAccepting = true){
            isAccepting = false;
        } else {
            isAccepting = true;
        }

    }

    @Override 
    public int removeSmallest() {
        //check to see if machine is in extraction mode

        if (isAccepting) {
            throw new IllegalStateException("Machine is not accepting entries");
        }
        int Smallest = contents.removeLast();

        return contents.getLast();
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public String toString() {
        String result = "";
        for (Integer item : contents){
            result = result + " " + item;
        }
        return result;
    }
}
