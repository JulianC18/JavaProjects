package model;

public interface ISortinator {
    void add(int toAdd);

    void crank();

    int removeSmallest();

    boolean isEmpty();

    // Add toString method to the interface
    String toString();
}
