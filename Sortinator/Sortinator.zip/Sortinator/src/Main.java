import model.EagerImpl;
import model.ISortinator;
import view.SortinatorView;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Create the model
            ISortinator model = new EagerImpl();

            // Create the view
            SortinatorView view = new SortinatorView();

            // Create the controller
            Controller controller = new Controller(model, view);

            // Set up the view
            view.setVisible(true);
        });
    }
}